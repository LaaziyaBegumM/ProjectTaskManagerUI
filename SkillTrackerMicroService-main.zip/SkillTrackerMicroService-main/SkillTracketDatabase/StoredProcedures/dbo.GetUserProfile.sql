﻿CREATE PROCEDURE [dbo].[GetUserProfile]
	@AssociateId nvarchar(30) =NULL,
	@AssociateName nvarchar(30)= NULL,
	@SkillName nvarchar(30)=NULL 
AS
BEGIN
	IF @AssociateId IS NOT NULL
	BEGIN
		SELECT AssociateId,AssociateName as [Name],Email,Mobile FROM UserProfile WHERE AssociateId=@AssociateId 
		SELECT AssociateId,SkillName as TechSkillName,SkillLevel as ExpertLevel FROM UserTechSkillMap WHERE AssociateId=@AssociateId AND SkillLevel>10 AND SkillName like @SkillName ORDER BY SkillLevel
		SELECT AssociateId,SkillName as NonTechSkillName,SkillLevel as ExpertLevel FROM UserNonTechSkillMap WHERE AssociateId=@AssociateId AND SkillLevel>10 AND SkillName like @SkillName ORDER BY SkillLevel
	END
	IF  @AssociateName IS NOT NULL
	BEGIN
		SELECT AssociateId,AssociateName as [Name],Email,Mobile FROM UserProfile WHERE AssociateId in (SELECT AssociateId FROM UserProfile WHERE AssociateName LIKE @AssociateName )
		SELECT AssociateId,SkillName as TechSkillName,SkillLevel as ExpertLevel FROM UserTechSkillMap WHERE AssociateId in (SELECT AssociateId FROM UserProfile WHERE AssociateName LIKE @AssociateName ) AND SkillLevel>10 ORDER BY SkillLevel --AND SkillName like @SkillName 
		SELECT AssociateId,SkillName as NonTechSkillName,SkillLevel as ExpertLevel FROM UserNonTechSkillMap WHERE AssociateId in (SELECT AssociateId FROM UserProfile WHERE AssociateName LIKE @AssociateName ) AND SkillLevel>10  ORDER BY SkillLevel --AND SkillName like @SkillName
	END
	IF  @SkillName IS NOT NULL
	BEGIN
		DECLARE @IsTechSkill bit =0
		IF (SELECT TOP 1 1  FROM UserTechSkillMap WHERE SkillLevel>10 AND SkillName like @SkillName ORDER BY SkillLevel)>0
		BEGIN
			SET @IsTechSkill=1			
		END		
		IF @IsTechSkill=0
		BEGIN
			SELECT AssociateId,AssociateName as [Name],Email,Mobile FROM UserProfile WHERE AssociateId IN (SELECT AssociateId 
			FROM UserNonTechSkillMap WHERE  SkillLevel>10 AND (SkillName like @SkillName))	
			SELECT AssociateId,SkillName as TechSkillName,SkillLevel as ExpertLevel FROM UserTechSkillMap WHERE AssociateId IN (SELECT AssociateId 
			FROM UserNonTechSkillMap WHERE  SkillLevel>10 AND (SkillName like @SkillName))	ORDER BY SkillLevel 
			SELECT AssociateId,SkillName as NonTechSkillName,SkillLevel as ExpertLevel FROM UserNonTechSkillMap WHERE  SkillLevel>10 AND (SkillName like @SkillName) ORDER BY SkillLevel 
		END
		ELSE IF @IsTechSkill=1
		BEGIN
			SELECT AssociateId,AssociateName as [Name],Email,Mobile FROM UserProfile WHERE AssociateId IN (SELECT AssociateId
			FROM UserTechSkillMap WHERE SkillLevel>10 AND  (SkillName like @SkillName OR @IsTechSkill=1))
			SELECT AssociateId,SkillName as TechSkillName,SkillLevel as ExpertLevel FROM UserTechSkillMap WHERE SkillLevel>10 AND  (SkillName like @SkillName OR @IsTechSkill=1)   ORDER BY SkillLevel
		    SELECT AssociateId,SkillName as TechSkillName,SkillLevel as ExpertLevel FROM UserNonTechSkillMap WHERE AssociateId IN (SELECT AssociateId
			FROM UserTechSkillMap WHERE SkillLevel>10 AND  (SkillName like @SkillName OR @IsTechSkill=1))
		END
	END	
END

