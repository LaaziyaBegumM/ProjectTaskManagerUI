﻿CREATE PROCEDURE [dbo].[UpdateUserProfile]
	@AssociateId nvarchar(30),
	@TechSkillData TechSkillType readonly,
	@NonTechSkillData NonTechSkillType readonly,
	@Status int output
AS
BEGIN TRY
	DECLARE @CreatedOn datetime,@TeckSkilltbleCount int, @NonTechSkilltblCount int, @TechSkill nvarchar(50), @TechSkillLevel int, @NonTechSkill nvarchar(50),
	@NonTechSkillLevel int,@Count int
	DECLARE @TechSkillWithRowNumber Table(RowNum bigint, SkillName nvarchar(50), SkillLevel int)
	INSERT INTO @TechSkillWithRowNumber(RowNum,SkillName,SkillLevel)
	SELECT ROW_NUMBER() OVER (ORDER BY SkillName) RowNum,SkillName,SkillLevel FROM @TechSkillData

	SET @TeckSkilltbleCount=(SELECT COUNT(1) FROM @TechSkillData)
	SET @Count=1

	WHILE @Count<=@TeckSkilltbleCount
	BEGIN
		SELECT @TechSkill=SkillName, @TechSkillLevel=SkillLevel FROM @TechSkillWithRowNumber WHERE ISNULL(RowNum,0)=@Count
		IF @TechSkillLevel<> (SELECT SkillLevel FROM UserTechSkillMap WHERE SkillName=@TechSkill AND AssociateId=@AssociateId)
			UPDATE UserTechSkillMap SET SkillLevel =@TechSkillLevel WHERE SkillName=@TechSkill AND AssociateId=@AssociateId 
			UPDATE UserProfile SET UpdatedBy='System', UpdatedOn=GETDATE() WHERE AssociateId=@AssociateId 
			SET @Count=@Count+1
	END

	DECLARE @NonTechSkillWithRowNumber Table(RowNum bigint, SkillName nvarchar(50), SkillLevel int)
	INSERT INTO @NonTechSkillWithRowNumber(RowNum,SkillName,SkillLevel)
	SELECT ROW_NUMBER() OVER (ORDER BY SkillName) RowNum,SkillName,SkillLevel FROM @NonTechSkillData

	SET @NonTechSkilltblCount=(SELECT COUNT(1) FROM @NonTechSkillData)
	SET @Count=1

	WHILE @Count<=@NonTechSkilltblCount
	BEGIN
		SELECT @TechSkill=SkillName, @TechSkillLevel=SkillLevel FROM @NonTechSkillWithRowNumber WHERE ISNULL(RowNum,0)=@Count
		IF @TechSkillLevel<> (SELECT SkillLevel FROM UserNonTechSkillMap WHERE SkillName=@TechSkill AND AssociateId=@AssociateId)
			UPDATE UserNonTechSkillMap SET SkillLevel =@TechSkillLevel WHERE SkillName=@TechSkill AND AssociateId=@AssociateId 
			UPDATE UserProfile SET UpdatedBy='System', UpdatedOn=GETDATE() WHERE AssociateId=@AssociateId 
			SET @Count=@Count+1
	END
	SET @Status=1
END TRY
BEGIN CATCH
	INSERT INTO DbErrorLog VALUES(ERROR_NUMBER(),ERROR_SEVERITY(),ERROR_STATE(),ERROR_PROCEDURE(),GETUTCDATE(),ERROR_LINE(),ERROR_MESSAGE())
	SET @Status=0
END CATCH

