﻿CREATE PROCEDURE [dbo].[ProfileUpdateCheck]
	@AssociateId nvarchar(30)
AS
	SELECT TOP 1 1 FROM UserProfile WHERE AssociateId=@AssociateId AND DATEDIFF(day,ISNULL(UpdatedOn,CreatedOn),GETDATE())>=10

