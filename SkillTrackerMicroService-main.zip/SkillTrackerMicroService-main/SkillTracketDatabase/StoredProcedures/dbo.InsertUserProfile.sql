﻿CREATE PROCEDURE [dbo].[InsertUserProfile]
	@AssociateId nvarchar(30),
	@Name nvarchar(30),
	@Mobile nvarchar(10),
	@Email nvarchar(50),
	@TechSkillData TechSkillType readonly,
	@NonTechSkillData NonTechSkillType readonly,
	@Status int output
AS
BEGIN TRY
	INSERT INTO UserProfile VALUES(@AssociateId,@Name,@Mobile,@Email,'System',GETDATE(),null,null)

	INSERT INTO UserTechSkillMap 
	SELECT @AssociateId,SkillName,SkillLevel FROM @TechSkillData

	INSERT INTO UserNonTechSkillMap
	SELECT @AssociateId,SkillName,SkillLevel FROM @NonTechSkillData

	SET @Status=1
END TRY
BEGIN CATCH
	INSERT INTO DbErrorLog VALUES(ERROR_NUMBER(),ERROR_SEVERITY(),ERROR_STATE(),ERROR_PROCEDURE(),GETUTCDATE(),ERROR_LINE(),ERROR_MESSAGE())
	SET @Status=0
END CATCH

