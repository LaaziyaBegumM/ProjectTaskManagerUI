﻿CREATE PROCEDURE [dbo].[CheckUserExist]
	@AssociateId nvarchar(30)
AS
	SELECT TOP 1 1 FROM UserProfile WHERE AssociateId=@AssociateId

