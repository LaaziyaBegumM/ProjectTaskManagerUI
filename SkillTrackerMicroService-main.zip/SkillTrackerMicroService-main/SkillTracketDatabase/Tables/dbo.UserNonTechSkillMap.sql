﻿CREATE TABLE [dbo].[UserNonTechSkillMap]
(
    [Id] INT IDENTITY(1,1) NOT NULL,
	[AssociateId] NVARCHAR(30) NOT NULL , 
    [SkillName] NVARCHAR(50) NOT NULL, 
    [SkillLevel] INT NOT NULL, 
    CONSTRAINT [PK_UserNonTechSkillMap] PRIMARY KEY ([Id])
)
GO
ALTER TABLE [dbo].[UserNonTechSkillMap] ADD CONSTRAINT [UserNoNTechSkillMap_AssociateId] FOREIGN KEY([AssociateId])
REFERENCES [dbo].[UserProfile]([AssociateId])
GO
ALTER TABLE [dbo].[UserNonTechSkillMap] CHECK CONSTRAINT [UserNoNTechSkillMap_AssociateId] 
