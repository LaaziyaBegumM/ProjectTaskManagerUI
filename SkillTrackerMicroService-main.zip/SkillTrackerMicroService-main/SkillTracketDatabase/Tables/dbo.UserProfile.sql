﻿CREATE TABLE [dbo].[UserProfile]
(
	[AssociateId] NVARCHAR(30) NOT NULL , 
    [AssociateName] NVARCHAR(30) NOT NULL, 
    [Mobile] NVARCHAR(10) NOT NULL, 
    [Email] NVARCHAR(50) NOT NULL, 
    [CreatedBy] NVARCHAR(30) NOT NULL, 
    [CreatedOn] DATETIME NOT NULL, 
    [UpdatedBy] NVARCHAR(30) NULL, 
    [UpdatedOn] DATETIME NULL, 
    CONSTRAINT [PK_UserProfile] PRIMARY KEY ([AssociateId])
)
