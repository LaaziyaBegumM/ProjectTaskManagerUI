﻿CREATE TABLE [dbo].[UserTechSkillMap]
(
    [Id] INT IDENTITY(1,1) NOT NULL,
	[AssociateId] NVARCHAR(30) NOT NULL , 
    SkillName NVARCHAR(50) NOT NULL, 
    [SkillLevel] INT NOT NULL, 
    CONSTRAINT [PK_UserTechSkillMap] PRIMARY KEY ([Id])
)
GO
ALTER TABLE [dbo].[UserTechSkillMap] ADD CONSTRAINT [UserTechSkillMap_AssociateId] FOREIGN KEY([AssociateId])
REFERENCES [dbo].[UserProfile]([AssociateId])
GO
ALTER TABLE [dbo].[UserTechSkillMap] CHECK CONSTRAINT [UserTechSkillMap_AssociateId] 
