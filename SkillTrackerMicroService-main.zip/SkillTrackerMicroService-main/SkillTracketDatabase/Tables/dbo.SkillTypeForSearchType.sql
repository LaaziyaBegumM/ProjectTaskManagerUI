﻿CREATE TYPE [dbo].[SkillTypeForSearchType] AS TABLE
(
	SkillName nvarchar(50)
)
