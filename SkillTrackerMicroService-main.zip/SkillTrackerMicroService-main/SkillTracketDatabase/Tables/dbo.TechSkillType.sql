﻿CREATE TYPE [dbo].[TechSkillType] AS TABLE
(
	SkillName nvarchar(50),
	SkillLevel int
)
