﻿CREATE TYPE [dbo].[NonTechSkillType] AS TABLE
(
	SkillName nvarchar(50),
	SkillLevel int
)
