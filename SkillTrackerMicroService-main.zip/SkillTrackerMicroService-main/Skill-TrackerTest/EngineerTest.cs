using AutoMapper;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using Skill_TrackerEngineerApi;
using Skill_TrackerEngineerApi.Controllers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Skill_TrackerTestEngineer
{
    public class EngineerTest
    {
        //private Mock<IProfileInsertRepo> mockInsert;
        private Mock<IMediator> mockMediator;
        //private Mock<IProfileUpdateRepo> mockUpdate;
        private Mock<ILogger<EngineerController>> mockLogger;
        private Mock<IBus> mockBus;
        private Mock<IPublishEndpoint> mockPublishEndPoint;
        private Mock<IMapper> mockMapper;
        private UserProfile user;
        private Status status;
        private List<TechnicalSkills> technicalSkills;
        private TechnicalSkills technical;
        private List<NonTechnicalSkills> nonTechnicalSkills;
        private NonTechnicalSkills nonTechnical;
        EngineerController controller;
        UserUpdateProfile userUpdateProfile;
        [SetUp]
        public void Setup()
        {
            //mockInsert = new Mock<IProfileInsertRepo>();
            //mockUpdate = new Mock<IProfileUpdateRepo>();
            mockMediator = new Mock<IMediator>();
            mockBus = new Mock<IBus>();
            mockPublishEndPoint = new Mock<IPublishEndpoint>();
            mockMapper = new Mock<IMapper>();
            //var mockInsertList = new List<IProfileInsertRepo>();
            //var mockUpdateList = new List<IProfileUpdateRepo>();
            //mockInsertList.Add(mockInsert.Object);
            //mockUpdateList.Add(mockUpdate.Object);
            mockLogger = new Mock<ILogger<EngineerController>>();
            technicalSkills = new List<TechnicalSkills>();
            technical = new TechnicalSkills();
            technical.TechSkillName = "C#";
            technical.ExpertLevel = 10;
            technicalSkills.Add(technical);
            technical = new TechnicalSkills();
            technical.TechSkillName = "Docket";
            technical.ExpertLevel = 2;
            technicalSkills.Add(technical);
            nonTechnicalSkills = new List<NonTechnicalSkills>();
            nonTechnical = new NonTechnicalSkills();
            nonTechnical.NonTechSkillName = "Spoken";
            nonTechnical.ExpertLevel = 15;
            nonTechnicalSkills.Add(nonTechnical);
            nonTechnical = new NonTechnicalSkills();
            nonTechnical.NonTechSkillName = "Attitude";
            nonTechnical.ExpertLevel = 20;
            nonTechnicalSkills.Add(nonTechnical);

            user = new UserProfile();
            user.AssociateId = "CTS56789";
            user.Email = "test@test.com";
            user.Mobile = "1234567890";
            user.Name = "john";
            user.NonTechnicalSkills = nonTechnicalSkills;
            user.TechnicalSkills = technicalSkills;

            status = new Status();
            status.StatusCode = 1000;
            status.StatusMessage = "sucess";
            status.Success = false;
            controller = new EngineerController(mockLogger.Object,mockMediator.Object, mockMapper.Object,mockPublishEndPoint.Object);
        }

        [Test]
        public async Task InsertProfilePositiveTest()
        {
            var result = await controller.Post(user) as ObjectResult;
            var actualResult = result.Value;
            var insertStatus = JsonConvert.SerializeObject(actualResult);
            var retObject = JsonConvert.DeserializeObject<Status>(insertStatus);
            Assert.IsNotNull(retObject);
            Assert.AreEqual(retObject.Success, status.Success);
        }
        [Test]
        public async Task InsertProfileExceptionTest()
        {
            user.AssociateId = "12345";
            string actualExceptionMessage = string.Empty;
            ObjectResult result = null;
            try
            {
                result = await controller.Post(user) as ObjectResult;
            }
            catch (System.Exception ex)
            {
                actualExceptionMessage = ex.Message;
            }
            string expectedExceptionMessage = "Associate Id should starts with CTS";
            Assert.AreEqual(expectedExceptionMessage,actualExceptionMessage);
        }

        [Test]
        public async Task UpdateProfileTest()
        {
            technicalSkills = new List<TechnicalSkills>();
            technical = new TechnicalSkills();
            technical.TechSkillName = "C#";
            technical.ExpertLevel = 9;
            technicalSkills.Add(technical);
            technical = new TechnicalSkills();
            technical.TechSkillName = "Docker";
            technical.ExpertLevel = 6;
            technicalSkills.Add(technical);
            nonTechnicalSkills = new List<NonTechnicalSkills>();
            nonTechnical = new NonTechnicalSkills();
            nonTechnical.NonTechSkillName = "Spoken";
            nonTechnical.ExpertLevel = 10;
            nonTechnicalSkills.Add(nonTechnical);
            nonTechnical = new NonTechnicalSkills();
            nonTechnical.NonTechSkillName = "Attitude";
            nonTechnical.ExpertLevel = 15;
            nonTechnicalSkills.Add(nonTechnical);
            userUpdateProfile = new UserUpdateProfile();
            userUpdateProfile.TechnicalSkills = technicalSkills;
            userUpdateProfile.NonTechnicalSkills = nonTechnicalSkills;
            var result = await controller.Update("CTS12345", userUpdateProfile) as ObjectResult;
            var actualResult = result.Value;
            var UpdateStatus = JsonConvert.SerializeObject(actualResult);
            var retObject = JsonConvert.DeserializeObject<Status>(UpdateStatus);
            Assert.IsNotNull(retObject);
            Assert.AreEqual(retObject.Success, status.Success);
        }
    }
}