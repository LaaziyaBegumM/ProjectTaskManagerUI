﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using Skill_TrackerAdminApi;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;


namespace Skill_TrackerTest
{
    public class AdminTest
    {
        private Mock<ILogger<AdminController>> mockLogger;
        AdminController controller;
        private ISkillTrackerProvider skillTrackerProvider;
        IConfiguration config;
        private Mock<IMediator> mockMediator;
        [SetUp]
        public void Setup()
        {
            config = new ConfigurationBuilder().
                SetBasePath(Directory.GetCurrentDirectory()).
                AddJsonFile("appsettings.development.json", optional: false, reloadOnChange: true).Build();
            config.Bind(AppSettings.GetInstance());
            skillTrackerProvider = new SkillTrackerProvider();
            mockLogger = new Mock<ILogger<AdminController>>();
            //var mockSearchList = new List<IProfileSearchRepo>();
            //mockSearchList.Add(searchRepo);
            mockMediator = new Mock<IMediator>();
            controller = new AdminController(mockLogger.Object, mockMediator.Object);
        }
        [Test]
        public async Task GetProfileCriteria1PositiveTest()
        {
            var result = await controller.Get("AssociateId","CTS12345") as ObjectResult;
            var actualResult = result.Value;
            var userProfile = JsonConvert.SerializeObject(actualResult);
            var userDetails = JsonConvert.DeserializeObject<UserSearchProfile>(userProfile);
            Assert.IsNotNull(userDetails);
            Assert.AreEqual(userDetails.Name, "Peter");
        }
        [Test]
        public async Task GetProfileCriteria1NegativeTest()
        {
            var result = await controller.Get("AssociateId", "CTS1234") as ObjectResult;
            var actualResult = result.Value;
            var userProfile = JsonConvert.SerializeObject(actualResult);
            var userDetails = JsonConvert.DeserializeObject<UserSearchProfile>(userProfile);
            Assert.IsNull(userDetails);
        }
        [Test]
        public async Task GetProfileCriteria2PositiveTest()
        {
            var result = await controller.Get("Name", "pe") as ObjectResult;
            var actualResult = result.Value;
            var userProfile = JsonConvert.SerializeObject(actualResult);
            var userDetails = JsonConvert.DeserializeObject<UserSearchProfile>(userProfile);
            Assert.IsNotNull(userDetails);
            Assert.AreEqual(userDetails.Name, "Peter");
        }
        [Test]
        public async Task GetProfileCriteria2NegativeTest()
        {
            var result = await controller.Get("Name", "qwert") as ObjectResult;
            var actualResult = result.Value;
            var userProfile = JsonConvert.SerializeObject(actualResult);
            var userDetails = JsonConvert.DeserializeObject<UserSearchProfile>(userProfile);
            Assert.IsNull(userDetails);
        }
        [Test]
        public async Task GetProfileCriteria3PositiveTest()
        {
            var result = await controller.Get("Skill", "C#") as ObjectResult;
            var actualResult = result.Value;
            var userProfile = JsonConvert.SerializeObject(actualResult);
            var userDetails = JsonConvert.DeserializeObject<UserSearchProfile>(userProfile);
            Assert.IsNotNull(userDetails);
            Assert.AreEqual(userDetails.Name, "Peter");
        }
        [Test]
        public async Task GetProfileCriteria3NegativeTest()
        {
            var result = await controller.Get("Skill", "ML") as ObjectResult;
            var actualResult = result.Value;
            var userProfile = JsonConvert.SerializeObject(actualResult);
            var userDetails = JsonConvert.DeserializeObject<UserSearchProfile>(userProfile);
            Assert.IsNull(userDetails);
        }
        [Test]
        public async Task GetProfileCriteriaExceptionTest()
        {
            string actualExceptionMessage = string.Empty;
            ObjectResult result = null;
            try
            {
                result = await controller.Get("Mobile","1234567890") as ObjectResult;
            }
            catch (System.Exception ex)
            {
                actualExceptionMessage = ex.Message;
            }
            string expectedExceptionMessage = "Search criteria should be Name, Associate Id or Skill";
            Assert.AreEqual(expectedExceptionMessage, actualExceptionMessage);
        }
    }
}
