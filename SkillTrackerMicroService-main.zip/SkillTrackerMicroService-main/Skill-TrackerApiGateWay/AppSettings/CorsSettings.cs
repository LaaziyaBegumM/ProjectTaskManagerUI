﻿namespace Skill_TrackerApiGateway
{
    public class CorsSettings
    {
        public string[] Url { get; set; }
        public string PolicyName { get; set; }
    }
}
