﻿using Dapper;
using Skill_TrackerAdminApi.Dto;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using static Dapper.SqlMapper;

namespace Skill_TrackerAdminApi
{
    public class ProfileSearchRepo : IProfileSearchRepo
    {
        private readonly ISkillTrackerProvider _skillTrackerProvider;
        public ProfileSearchRepo(ISkillTrackerProvider skillTrackerProvider)
        {
            _skillTrackerProvider = skillTrackerProvider;
        }
        public async Task<Tuple<IEnumerable<UserSearchProfileDto>, IEnumerable<TechnicalSkillsDto>, IEnumerable<NonTechnicalSkillsDto>>> GetUserProfile(string criteria, string criteriaValue)
        {
            Tuple<IEnumerable<UserSearchProfileDto>, IEnumerable<TechnicalSkillsDto>, IEnumerable<NonTechnicalSkillsDto>> result = null;
            IEnumerable<UserSearchProfileDto> userProfile = null;
            IEnumerable<TechnicalSkillsDto> technicalSkills = null;
            IEnumerable<NonTechnicalSkillsDto> nonTechnicalSkills = null;
            string userId = string.Empty;
            string userName = string.Empty;
            string skill = string.Empty;
            if (criteria.ToLower().Equals("associateid"))
                userId = criteriaValue;
            if (criteria.ToLower().Equals("name"))
            {
                userName = criteriaValue;
                userName += "%";
            }
            if (criteria.ToLower().Equals( "skill"))
                skill = criteriaValue;
            using (var connection = _skillTrackerProvider.GetConnection())
            {
                var param = new DynamicParameters();
                param.Add("@AssociateId", (string.IsNullOrEmpty(userId))?null:userId, DbType.String);
                param.Add("@AssociateName", (string.IsNullOrEmpty(userName))?null:userName, DbType.String);
                param.Add("@SkillName", (string.IsNullOrEmpty(skill)) ? null : skill, DbType.String);
                GridReader gridReader = await connection.QueryMultipleSync("GetUserProfile", param, null, null, commandType: CommandType.StoredProcedure);

                if (!gridReader.IsConsumed)
                    userProfile = gridReader.Read<UserSearchProfileDto>();
                if (!gridReader.IsConsumed)
                    technicalSkills = gridReader.Read<TechnicalSkillsDto>();
                if (!gridReader.IsConsumed)
                    nonTechnicalSkills = gridReader.Read<NonTechnicalSkillsDto>();
                result = new Tuple<IEnumerable<UserSearchProfileDto>, IEnumerable<TechnicalSkillsDto>, IEnumerable<NonTechnicalSkillsDto>>(userProfile, technicalSkills, nonTechnicalSkills);
                return result;
             }
        }
    }
}
