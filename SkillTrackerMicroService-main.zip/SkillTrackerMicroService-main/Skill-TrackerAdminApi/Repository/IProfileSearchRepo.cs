﻿using Skill_TrackerAdminApi.Dto;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi
{
    public interface IProfileSearchRepo
    {
        Task<Tuple<IEnumerable<UserSearchProfileDto>, IEnumerable<TechnicalSkillsDto>, IEnumerable<NonTechnicalSkillsDto>>> GetUserProfile(string criteria, string criteriaValue);
    }
}
