﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi
{
    public class AppBaseController<T> : ControllerBase where T : AppBaseController<T>
    {
        public ILogger<T> AppLogger;
        public AppBaseController(ILogger<T> logger)
        {
            AppLogger = logger;
        }
        public G GetServiceInstance<G>(IEnumerable<G> serviceCollection)
        {
            return serviceCollection.FirstOrDefault();
        }
    }
}
