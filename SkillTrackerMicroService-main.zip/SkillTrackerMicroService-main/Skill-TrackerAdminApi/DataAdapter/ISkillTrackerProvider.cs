﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skill_TrackerAdminApi
{
    public interface ISkillTrackerProvider
    {
        SkillTrackerConnection GetConnection();
    }
}
