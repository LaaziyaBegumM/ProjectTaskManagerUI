﻿using Dapper;
using Microsoft.Practices.EnterpriseLibrary.TransientFaultHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi
{
    public class SkillTrackerConnection : ISkilltrackerConnection
    {
        private readonly IDbConnection _dbConnection;
        private readonly RetryPolicy _retryPolicy;
        public SkillTrackerConnection(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
            var retryStrategy = new FixedInterval(20, TimeSpan.FromMilliseconds(2000));
            _retryPolicy = new RetryPolicy<SqlDatabaseTransientErrorDetectionStrategy>(retryStrategy);
        }
        
        public Task ExecuteAsync(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null)
        {
            return _retryPolicy.ExecuteAction(() => _dbConnection.ExecuteAsync(sql, param, dbTransaction, commandTimeout, commandType));
        }

        public Task<T> ExecuteScalarAsync<T>(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null)
        {
            return _retryPolicy.ExecuteAction(() => _dbConnection.ExecuteScalarAsync<T>(sql, param, dbTransaction, commandTimeout, commandType));
        }

        public Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null)
        {
            return _retryPolicy.ExecuteAction(() => _dbConnection.QueryAsync<T>(sql, param, dbTransaction, commandTimeout, commandType));
        }

        private bool isDisposed=false;

        private void DisposeConnection(bool isDisposing)
        {
            if (!isDisposed)
            {
                if(isDisposing)
                {
                    _dbConnection.Dispose();
                }
            }
        }
        public void Dispose()
        {
            DisposeConnection(true);
        }

        public Task<SqlMapper.GridReader> QueryMultipleSync(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null)
        {
            return _retryPolicy.ExecuteAction(() => _dbConnection.QueryMultipleAsync(sql, param, dbTransaction, commandTimeout, commandType));
        }
    }
}
