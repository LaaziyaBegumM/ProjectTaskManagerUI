﻿using System;
using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi
{
    public interface ISkilltrackerConnection:IDisposable
    {
        /// <summary>
        /// Method used to get the collection based on the stored procedure
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <param name="dbTransaction"></param>
        /// <param name="commandTimeout"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null);
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <param name="dbTransaction"></param>
        /// <param name="commandTimeout"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        Task ExecuteAsync(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null);

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <param name="dbTransaction"></param>
        /// <param name="commandTimeout"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        Task<T>ExecuteScalarAsync<T>(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="param"></param>
        /// <param name="dbTransaction"></param>
        /// <param name="commandTimeout"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        Task<SqlMapper.GridReader> QueryMultipleSync(string sql, object param = null, IDbTransaction dbTransaction = null, int? commandTimeout = null, CommandType? commandType = null);
    }
}
