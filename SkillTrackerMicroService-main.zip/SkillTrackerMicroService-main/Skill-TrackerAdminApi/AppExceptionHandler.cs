﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi
{
    public class AppExceptionHandler
    {
        private readonly ILogger _logger;
        private readonly RequestDelegate _next;

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                context.Response.ContentType = "application/json";
                if (ex != null)
                {
                    _logger.LogError(ex,ex.Message);
                    await context.Response.WriteAsync(new ErrorDetails()
                    {
                        ErrorType = ex.GetType().Name,
                        Message = GetInnerExceptions(ex),
                        ErrorCode = ex.HResult
                    }.ToString());
                }
            }
        }

        public AppExceptionHandler(RequestDelegate next, ILogger<AppExceptionHandler> logger)
        {
            _logger = logger;
            _next = next;
        }

        /// <summary>
        /// Get all the inner exception
        /// </summary>
        /// <param name="ex">exception</param>
        /// <returns></returns>
        private static String GetInnerExceptions(Exception ex)
        {
            string exceptionMsg = string.Empty;

            while (ex.InnerException != null)
            {
                exceptionMsg += $" {ex.Message} || ";
                ex = ex.InnerException;
            }

            exceptionMsg += ex.Message;

            return exceptionMsg;
        }
    }
}