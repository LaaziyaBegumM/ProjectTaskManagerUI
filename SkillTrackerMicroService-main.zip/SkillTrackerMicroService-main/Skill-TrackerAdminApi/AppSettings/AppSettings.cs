﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skill_TrackerAdminApi
{
    public class AppSettings
    {
        private static AppSettings _appSettings;
        private AppSettings()
        {

        }

        public static AppSettings GetInstance()
        {
            if(_appSettings==null)
            {
                _appSettings = new AppSettings();
            }
            return _appSettings;
        }

        public ConnectionSettings ConnectionSettings { get; set; }
    }
}
