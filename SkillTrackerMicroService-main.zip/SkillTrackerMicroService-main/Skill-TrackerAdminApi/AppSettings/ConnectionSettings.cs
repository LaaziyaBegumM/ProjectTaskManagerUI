﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace Skill_TrackerAdminApi
{
    public class ConnectionSettings
    {
        public string SqlConnectionString
        {
            get;set;
        }
    }
}
