﻿
namespace Skill_TrackerAdminApi
{
    public class TechnicalSkills
    {
        public string TechSkillName { get; set; }
        public int ExpertLevel { get; set; }
    }
}
