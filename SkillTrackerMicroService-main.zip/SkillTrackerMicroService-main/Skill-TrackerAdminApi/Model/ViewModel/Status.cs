﻿
namespace Skill_TrackerAdminApi
{
    public class Status
    {
        public bool Success { get; set; }
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }
}
