﻿
namespace Skill_TrackerAdminApi
{
    public class NonTechnicalSkills
    {
        public string NonTechSkillName { get; set; }
        public int ExpertLevel { get; set; }
    }
}
