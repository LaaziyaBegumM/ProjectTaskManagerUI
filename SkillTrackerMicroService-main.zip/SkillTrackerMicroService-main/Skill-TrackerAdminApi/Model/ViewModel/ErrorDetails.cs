﻿using Newtonsoft.Json;
using System;

namespace Skill_TrackerAdminApi
{
    public class ErrorDetails
    {
        public string Message { get; set; }
        public int ErrorCode { get; set; }
        public string ErrorType { get; set; }
        public DateTime Timestamp { get; } = DateTime.UtcNow;

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}