﻿
namespace Skill_TrackerAdminApi.Dto
{
    public class NonTechnicalSkillsDto
    {
        public string AssociateId { get; set; }
        public string NonTechSkillName { get; set; }
        public int ExpertLevel { get; set; }
    }
}
