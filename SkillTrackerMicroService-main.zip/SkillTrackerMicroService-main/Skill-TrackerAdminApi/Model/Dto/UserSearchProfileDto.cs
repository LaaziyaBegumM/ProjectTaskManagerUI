﻿using System.Collections.Generic;

namespace Skill_TrackerAdminApi.Dto
{
    public class UserSearchProfileDto
    {
        public string AssociateId { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public List<TechnicalSkills> TechnicalSkills { get; set; }
        public List<NonTechnicalSkills> NonTechnicalSkills { get; set; }
    }
}
