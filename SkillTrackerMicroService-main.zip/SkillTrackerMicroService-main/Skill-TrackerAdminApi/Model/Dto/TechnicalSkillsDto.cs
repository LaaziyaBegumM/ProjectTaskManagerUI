﻿
namespace Skill_TrackerAdminApi.Dto
{
    public class TechnicalSkillsDto
    {
        public string AssociateId { get; set; }
        public string TechSkillName { get; set; }
        public int ExpertLevel { get; set; }
    }
}
