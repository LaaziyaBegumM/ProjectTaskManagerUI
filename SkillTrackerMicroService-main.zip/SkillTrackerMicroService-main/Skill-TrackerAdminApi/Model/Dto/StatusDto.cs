﻿
namespace Skill_TrackerAdminApi.Dto
{
    public class StatusDto
    {
        public bool Success { get; set; }
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }
}
