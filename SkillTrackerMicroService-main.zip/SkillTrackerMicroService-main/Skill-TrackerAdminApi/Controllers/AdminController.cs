﻿using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Skill_TrackerAdminApi.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi
{
    [Route("api/admin")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly ILogger<AdminController> _logger;
        private readonly IMediator _mediator;
        public AdminController(ILogger<AdminController> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        [HttpGet("{criteria}/{criteriaValue}")]
        [EnableCors("AllowOrigin")]
        public async Task<IActionResult> Get(string criteria, string criteriaValue)
        {
            List<string> lstCritera = new List<string>();
            lstCritera.Add("associateid");
            lstCritera.Add("name");
            lstCritera.Add("skill");
            if (!lstCritera.Contains(criteria.ToLower()))
                throw new Exception("Search criteria should be Name, Associate Id or Skill");
            var query = new GetUserProfileQuery { Criteria = criteria, CriteriaValue = criteriaValue };
            var users = await _mediator.Send(query);
            var userProfileList = users.Where(i => i.NonTechnicalSkills.Count > 0 || i.TechnicalSkills.Count > 0);
            var userProfile = userProfileList.ToArray();
            return Ok(new { userProfile });
        }
    }
}
