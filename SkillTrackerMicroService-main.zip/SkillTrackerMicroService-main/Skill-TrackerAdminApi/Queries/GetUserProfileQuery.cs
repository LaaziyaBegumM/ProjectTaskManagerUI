﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi.Queries
{
    public class GetUserProfileQuery:IRequest<IEnumerable<UserSearchProfile>>
    {
        public string Criteria { get; set; }
        public string CriteriaValue { get; set; }
    }
}
