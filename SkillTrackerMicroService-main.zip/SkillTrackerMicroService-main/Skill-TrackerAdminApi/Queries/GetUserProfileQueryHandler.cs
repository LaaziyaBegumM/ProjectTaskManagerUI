﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Skill_TrackerCommonObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Skill_TrackerAdminApi.Queries
{
    public class GetUserProfileQueryHandler : IRequestHandler<GetUserProfileQuery, IEnumerable<UserSearchProfile>>
    {
        private readonly IProfileSearchRepo _profileSearchRepo;
        private readonly IMapper _mapper;
        private readonly ILogger<GetUserProfileQueryHandler> _logger;
        private readonly IDistributedCache _distributedCache;

        public GetUserProfileQueryHandler(IProfileSearchRepo profileSearchRepo,IMapper mapper, ILogger<GetUserProfileQueryHandler> logger, IDistributedCache distributedCache)
        {
            _profileSearchRepo = profileSearchRepo;
            _mapper = mapper;
            _logger = logger;
            _distributedCache = distributedCache;
        }
        public async Task<IEnumerable<UserSearchProfile>> Handle(GetUserProfileQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Query handler start");
            var criteria = request.Criteria;
            var criteraValue = request.CriteriaValue;
            var cacheKey = Constants.CacheKey + criteraValue;
            var cacheData = await _distributedCache.GetAsync(cacheKey);
            IEnumerable <UserSearchProfile> userSearchProfile = null;
            if (cacheData != null)
            {
                var searilsedObject = Encoding.UTF8.GetString(cacheData);
                userSearchProfile = JsonConvert.DeserializeObject<IEnumerable<UserSearchProfile>>(searilsedObject);
            }
            else
            {

                var profileData = await _profileSearchRepo.GetUserProfile(criteria, criteraValue);
                if (profileData == null)
                    return null;
                userSearchProfile = (from data in profileData.Item1
                                     select new UserSearchProfile
                                     {
                                         AssociateId = data.AssociateId,
                                         Email = data.Email,
                                         Mobile = data.Mobile,
                                         Name = data.Name,
                                         TechnicalSkills = (from techData in profileData.Item2
                                                            where techData.AssociateId == data.AssociateId
                                                            select new TechnicalSkills
                                                            {
                                                                ExpertLevel = techData.ExpertLevel,
                                                                TechSkillName = techData.TechSkillName
                                                            }).OrderByDescending(i => i.ExpertLevel).ToList(),
                                         NonTechnicalSkills = (from nonTechData in profileData.Item3
                                                               where nonTechData.AssociateId == data.AssociateId
                                                               select new NonTechnicalSkills
                                                               {
                                                                   ExpertLevel = nonTechData.ExpertLevel,
                                                                   NonTechSkillName = nonTechData.NonTechSkillName
                                                               }).OrderByDescending(i => i.ExpertLevel).ToList()
                                     });
                var jsonData = JsonConvert.SerializeObject(userSearchProfile);
                var byteData = Encoding.UTF8.GetBytes(jsonData);
                var cacheOptions = new DistributedCacheEntryOptions()
                   .SetAbsoluteExpiration(DateTime.Now.AddMinutes(5))
                   .SetSlidingExpiration(TimeSpan.FromMinutes(2));
                await _distributedCache.SetAsync(cacheKey, byteData);
            }
            _logger.LogInformation("Query handler end");
            return userSearchProfile;
        }
    }
}
