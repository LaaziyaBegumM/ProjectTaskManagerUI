﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Skill_TrackerEngineerApi
{
    public class UserUpdateProfile
    {
        [Required(ErrorMessage = "Associate Id is Mandatory")]
        [StringLength(30, ErrorMessage = "AssocaiteId should be minimum 5 characters and maximum 30 characters", MinimumLength = 5)]
        public string AssociateId { get; set; }
        public List<TechnicalSkills> TechnicalSkills { get; set; }
        public List<NonTechnicalSkills> NonTechnicalSkills { get; set; }
    }
}
