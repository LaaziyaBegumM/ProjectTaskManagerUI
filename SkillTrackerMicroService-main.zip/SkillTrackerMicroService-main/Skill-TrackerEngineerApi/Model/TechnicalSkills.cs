﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Skill_TrackerEngineerApi
{
    public class TechnicalSkills
    {
        public string TechSkillName { get; set; }
        [Required(ErrorMessage = "Each skill should have a valid skill level")]
        [Range(0,20,ErrorMessage ="Skill Level should be between 0 and 20")]
        public int ExpertLevel { get; set; }
    }
}
