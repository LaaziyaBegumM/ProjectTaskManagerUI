﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Skill_TrackerEngineerApi
{
    public class UserProfile
    {
        [Required(ErrorMessage = "Associate Id is Mandatory")]
        [StringLength(30, ErrorMessage = "AssocaiteId should be minimum 5 characters and maximum 30 characters", MinimumLength = 5)]
        public string AssociateId { get; set; }
        [Required(ErrorMessage = "Associate Name is Mandatory")]
        [StringLength(30, ErrorMessage = "Assocaite Name should be minimum 5 characters and maximum 30 characters", MinimumLength = 5)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Mobil number is Mandatory")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Mobile number should be 10 digits")]
        public string Mobile { get; set; }
        [Required(ErrorMessage = "Email Id is Mandatory")]
        [EmailAddress]
        public string Email { get; set; }
        public List<TechnicalSkills> TechnicalSkills { get; set; }
        public List<NonTechnicalSkills> NonTechnicalSkills { get; set; }
    }
}
