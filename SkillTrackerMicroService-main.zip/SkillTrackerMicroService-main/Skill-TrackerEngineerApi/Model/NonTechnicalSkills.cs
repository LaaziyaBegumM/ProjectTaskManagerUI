﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Skill_TrackerEngineerApi
{
    public class NonTechnicalSkills
    {
        //[DefaultValue("SPOKEN, COMMUNICATION, ATTITUDE")]
        public string NonTechSkillName { get; set; }
        [Required(ErrorMessage = "Each skill should have a valid skill level")]
        [Range(0, 20, ErrorMessage = "Skill Level should be between 0 and 20")]
        public int ExpertLevel { get; set; }
    }
}
