﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skill_TrackerEngineerApi
{
    public class Status
    {
        public bool Success { get; set; }
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }
}
