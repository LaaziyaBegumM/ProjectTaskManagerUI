﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi.Command
{
    public class CheckProfileEditableCommandHandler : IRequestHandler<CheckProfileEditableCommand, bool>
    {
        private readonly ILogger<CheckProfileEditableCommandHandler> _logger;
        private readonly IProfileUpdateRepo _profileUpdateRepo;
        private readonly IMapper _mapper;
        public CheckProfileEditableCommandHandler(ILogger<CheckProfileEditableCommandHandler> logger, IProfileUpdateRepo profileUpdateRepo, IMapper mapper)
        {
            _logger = logger;
            _profileUpdateRepo = profileUpdateRepo;
            _mapper = mapper;
        }
        public async Task<bool> Handle(CheckProfileEditableCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("CheckProfileEditableCommand handler start");
            var userId = request.UserId;
            var isEditable = await _profileUpdateRepo.IsProfileEditable(userId);
            _logger.LogInformation("CheckProfileEditableCommand handler end");
            return isEditable;
        }
    }
}
