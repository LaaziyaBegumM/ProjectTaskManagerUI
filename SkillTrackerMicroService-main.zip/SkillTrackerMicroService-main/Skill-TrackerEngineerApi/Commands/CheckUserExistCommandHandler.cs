﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public class CheckUserExistCommandHandler : IRequestHandler<CheckUserExistCommand, bool>
    {
        private readonly ILogger<CheckUserExistCommandHandler> _logger;
        private readonly IProfileInsertRepo _profileInsertRepo;
        private readonly IMapper _mapper;
        public CheckUserExistCommandHandler(ILogger<CheckUserExistCommandHandler> logger, IProfileInsertRepo profileInsertRepo , IMapper mapper)
        {
            _logger = logger;
            _profileInsertRepo = profileInsertRepo;
            _mapper = mapper;
        }
        public async Task<bool> Handle(CheckUserExistCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("CheckUserExistCommand handler start");
            var userId = request.UserId;
            var status = await _profileInsertRepo.CheckuserExist(userId);
            _logger.LogInformation("CheckUserExistCommand handler end");
            return status;
        }
    }
}
