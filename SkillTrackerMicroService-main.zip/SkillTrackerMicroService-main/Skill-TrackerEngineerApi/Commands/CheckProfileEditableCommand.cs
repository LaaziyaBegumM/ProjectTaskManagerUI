﻿using MediatR;

namespace Skill_TrackerEngineerApi
{
    public class CheckProfileEditableCommand:IRequest<bool>
    {
        public string UserId { get; set; }
    }
}
