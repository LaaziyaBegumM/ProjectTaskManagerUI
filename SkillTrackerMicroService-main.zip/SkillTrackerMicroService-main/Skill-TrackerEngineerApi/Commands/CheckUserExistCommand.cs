﻿using MediatR;

namespace Skill_TrackerEngineerApi
{
    public class CheckUserExistCommand:IRequest<bool>
    {
        public string UserId { get; set; }
    }
}
