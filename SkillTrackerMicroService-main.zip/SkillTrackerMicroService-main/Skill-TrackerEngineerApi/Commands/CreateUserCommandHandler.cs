﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, Status>
    {
        private readonly ILogger<CreateUserCommandHandler> _logger;
        private readonly IProfileInsertRepo _profileInsertRepo;
        private readonly IMapper _mapper;

        public CreateUserCommandHandler(IProfileInsertRepo profileInsertRepo, ILogger<CreateUserCommandHandler> logger,IMapper mapper)
        {
            _profileInsertRepo = profileInsertRepo;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Status> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("CreateUserCommand handler start");         
            var userProfile = _mapper.Map<UserProfile>(request);   
            var status = await _profileInsertRepo.InsertUserProfile(userProfile);
            _logger.LogInformation("CreateUserCommand handler end");
            return status;
        }
    }
}
