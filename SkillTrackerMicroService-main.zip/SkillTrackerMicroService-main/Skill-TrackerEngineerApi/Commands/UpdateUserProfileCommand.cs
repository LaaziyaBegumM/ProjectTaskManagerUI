﻿using MediatR;
using System.Collections.Generic;

namespace Skill_TrackerEngineerApi
{
    public class UpdateUserProfileCommand:IRequest<Status>
    {
        public string AssociateId { get; set; }
        public List<TechnicalSkills> TechnicalSkills { get; set; }
        public List<NonTechnicalSkills> NonTechnicalSkills { get; set; }
    }
}
