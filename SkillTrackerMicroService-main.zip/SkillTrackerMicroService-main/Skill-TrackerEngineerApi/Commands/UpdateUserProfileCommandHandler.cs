﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public class UpdateUserProfileCommandHandler : IRequestHandler<UpdateUserProfileCommand, Status>
    {
        private readonly ILogger<UpdateUserProfileCommandHandler> _logger;
        private readonly IProfileUpdateRepo _profileUpdateRepo;
        private readonly IMapper _mapper;
        private readonly IDistributedCache _distributedCache;
        public UpdateUserProfileCommandHandler(ILogger<UpdateUserProfileCommandHandler> logger, IProfileUpdateRepo profileUpdateRepo, IMapper mapper, IDistributedCache distributedCache)
        {
            _logger = logger;
            _profileUpdateRepo = profileUpdateRepo;
            _mapper = mapper;
            _distributedCache = distributedCache;
        }
        public async Task<Status> Handle(UpdateUserProfileCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("UpdateUserProfileCommand handler start");
            var userId = request.AssociateId;
            var isEditable = await _profileUpdateRepo.IsProfileEditable(userId);
            if (isEditable == false)
            {
                throw new Exception("Profile can update only after 10 days from the date of creation");
            }
            var updatedProfile = _mapper.Map<UserUpdateProfile>(request);
            var status = await _profileUpdateRepo.UpdateUserProfile(updatedProfile);
            _logger.LogInformation("UpdateUserProfileCommand handler end");
            return status;
        }
    }
}
