﻿
namespace Skill_TrackerEngineerApi
{
    public class AppSettings
    {
        private static AppSettings _appSettings;
        private AppSettings()
        {

        }

        public static AppSettings GetInstance()
        {
            if(_appSettings==null)
            {
                _appSettings = new AppSettings();
            }
            return _appSettings;
        }

        public ConnectionSettings ConnectionSettings { get; set; }
    }
}
