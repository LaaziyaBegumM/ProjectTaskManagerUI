﻿using AutoMapper;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Skill_TrackerCommonObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi.Controllers
{
    [Route("api/engineer")]
    [ApiController]
    public class EngineerController : ControllerBase
    {
        private readonly ILogger<EngineerController> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IPublishEndpoint _publishEndpoint;
        public EngineerController(ILogger<EngineerController> logger, IMediator mediator,IMapper mapper,IPublishEndpoint publishEndpoint)
        {
            _logger = logger;
            _mediator = mediator;
            _publishEndpoint = publishEndpoint;
            _mapper = mapper;
        }
        [HttpPost]
        public async Task<IActionResult> Post(UserProfile user)
        {
            if (!user.AssociateId.ToUpper().StartsWith("CTS"))
            {
                throw new Exception("Associate Id should starts with CTS");
            }
            var checkUserExistCommand = new CheckUserExistCommand { UserId = user.AssociateId };
            var isUserExist = await _mediator.Send(checkUserExistCommand);
            if (isUserExist == true)
            {
                throw new Exception("Associate Id already exist");
            }            
            var userDetails = _mapper.Map<UserProfile, UserDetails>(user);
            _logger.LogInformation("Message producer start");
            await _publishEndpoint.Publish<UserDetails>(userDetails);
            _logger.LogInformation("Message producer end");
            return Accepted();
        }
        [HttpPut]
        public async Task<IActionResult> Update(string userId, [FromBody] UserUpdateProfile user)
        {
            var updateUserCommand = new UpdateUserProfileCommand { AssociateId = userId, TechnicalSkills = user.TechnicalSkills, NonTechnicalSkills = user.NonTechnicalSkills };
            var status = await _mediator.Send(updateUserCommand);
            if (status == null)
                return new NoContentResult();
            return Ok(new { status });
        }
    }
}
