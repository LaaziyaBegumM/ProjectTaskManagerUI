﻿using AutoMapper;
using MassTransit;
using MediatR;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Skill_TrackerCommonObjects;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public class MessageConsumer : IConsumer<UserDetails>
    {
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ILogger<MessageConsumer> _logger;

        public MessageConsumer(IMapper mapper,IMediator mediator, ILogger<MessageConsumer> logger)
        {
            _mapper = mapper;
            _mediator = mediator;
            _logger = logger;
        }
        public async Task Consume(ConsumeContext<UserDetails> context)
        {
            _logger.LogInformation("Message consumer start");
            var consumedData = _mapper.Map<CreateUserCommand>(context.Message);            
            var result = await _mediator.Send(consumedData);
            _logger.LogInformation("User profile message cosumed successfully, Created new user profile", result);
            _logger.LogInformation("Message consumer end");
        }
    }
}
