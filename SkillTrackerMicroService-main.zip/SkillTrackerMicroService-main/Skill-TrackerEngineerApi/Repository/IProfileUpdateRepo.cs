﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public interface IProfileUpdateRepo
    {
        Task<bool> IsProfileEditable(string associateId);
        Task<Status> UpdateUserProfile(UserUpdateProfile userProfile);
    }
}
