﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public interface IProfileInsertRepo
    {
        Task<Status> InsertUserProfile(UserProfile userProfile);
        Task<bool> CheckuserExist(string userId);
    }
}
