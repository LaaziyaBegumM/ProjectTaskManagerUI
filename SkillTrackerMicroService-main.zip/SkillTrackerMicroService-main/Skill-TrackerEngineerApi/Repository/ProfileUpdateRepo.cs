﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Skill_TrackerEngineerApi
{
    public class ProfileUpdateRepo:IProfileUpdateRepo
    {
        private readonly ISkillTrackerProvider _skillTrackerProvider;
        public ProfileUpdateRepo(ISkillTrackerProvider skillTrackerProvider)
        {
            _skillTrackerProvider = skillTrackerProvider;
        }

        public async Task<bool> IsProfileEditable(string associateId)
        {
            using(var connection=_skillTrackerProvider.GetConnection())
            {
                var param = new DynamicParameters();
                param.Add("@AssociateId", associateId, DbType.String);
                var returnValue = await connection.QueryAsync<bool>("ProfileUpdateCheck", param, null, null, commandType: CommandType.StoredProcedure);
                return Convert.ToBoolean(returnValue.FirstOrDefault());
            }           
        }

        public async Task<Status> UpdateUserProfile(UserUpdateProfile user)
        {
            Status status;
            int? returnValue = null;
            
            using (var connecion = _skillTrackerProvider.GetConnection())
            {
                DataTable dtTechSkill = new DataTable("TechSkillType");
                dtTechSkill.Columns.Add("SkillName", typeof(string));
                dtTechSkill.Columns.Add("SkillLevel", typeof(int));
                foreach (var tech in user.TechnicalSkills)
                {
                    dtTechSkill.Rows.Add(tech.TechSkillName, tech.ExpertLevel);
                } 
                DataTable dtNonTechSkill = new DataTable("NonTechSkillType");
                dtNonTechSkill.Columns.Add("SkillName", typeof(string));
                dtNonTechSkill.Columns.Add("SkillLevel", typeof(int));
                foreach (var nonTech in user.NonTechnicalSkills)
                {
                    dtNonTechSkill.Rows.Add(nonTech.NonTechSkillName, nonTech.ExpertLevel);
                }
                var param = new DynamicParameters();
                param.Add("@AssociateId", user.AssociateId, DbType.String);
                param.Add("@TechSkillData", dtTechSkill.AsTableValuedParameter("TechSkillType"), DbType.Object);
                param.Add("@NonTechSkillData", dtNonTechSkill.AsTableValuedParameter("NonTechSkillType"), DbType.Object);
                param.Add("@Status", DbType.Int32, direction: ParameterDirection.Output);
                await connecion.ExecuteAsync("UpdateUserProfile", param, null, null, commandType: CommandType.StoredProcedure);
                returnValue = param.Get<int?>("@Status");
            }
            if (returnValue == 1)
            {
                status = new Status();
                status.StatusCode = 1000;
                status.Success = true;
                status.StatusMessage = "Profile details updated successfully !!!";
            }
            else
            {
                status = new Status();
                status.StatusCode = 1100;
                status.Success = false; 
                status.StatusMessage = "Profile updation failed !!!";
            }
            return status;
        }
    }
}
