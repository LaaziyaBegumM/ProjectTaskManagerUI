﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace Skill_TrackerEngineerApi
{
    public class SkillTrackerProvider : ISkillTrackerProvider
    {
        public SkillTrackerProvider()
        {

        }
        public SkillTrackerConnection GetConnection()
        {
            return new SkillTrackerConnection(new SqlConnection(AppSettings.GetInstance().ConnectionSettings.SqlConnectionString));
        }
    }
}
