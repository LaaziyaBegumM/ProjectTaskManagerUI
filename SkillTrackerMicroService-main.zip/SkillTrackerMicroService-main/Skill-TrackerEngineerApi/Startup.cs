using GreenPipes;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Skill_TrackerCommonObjects;
using System;
using System.Reflection;

namespace Skill_TrackerEngineerApi
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            //Initialize all the appSetting 
            Configuration.Bind(AppSettings.GetInstance());
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSingleton<IProfileInsertRepo, ProfileInsertRepo>();
            services.AddSingleton<IProfileUpdateRepo, ProfileUpdateRepo>();
            services.AddSingleton<ISkillTrackerProvider>(i => new SkillTrackerProvider());
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddMassTransit(x =>
            {
                x.AddConsumer<MessageConsumer>();
                x.AddBus(provider => Bus.Factory.CreateUsingRabbitMq(config =>
                {
                    config.Host(new Uri(RabbitMqConsts.RabbitMqRootUri), h =>
                    {
                        h.Username(RabbitMqConsts.UserName);
                        h.Password(RabbitMqConsts.Password);
                    });
                    config.ReceiveEndpoint("userqueue", ep =>
                    {
                       ep.ConfigureConsumer<MessageConsumer>(provider);
                    });
                }));
            });
            services.AddMassTransitHostedService();
            services.AddMediatR(Assembly.GetExecutingAssembly());
            services.AddStackExchangeRedisCache(options => {
                options.Configuration = "localhost:6379";
            });
            services.AddOpenApiDocument(configure => { configure.Title = "Skill Tracker Engineer Web API"; });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            
            app.UseOpenApi();

            app.UseSwaggerUi3();

            app.UseMiddleware<AppExceptionHandler>();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
