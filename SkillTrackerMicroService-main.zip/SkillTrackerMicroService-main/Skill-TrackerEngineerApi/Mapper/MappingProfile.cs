﻿using AutoMapper;
using Skill_TrackerCommonObjects;


namespace Skill_TrackerEngineerApi.Mapper
{
    public class MappingProfile:Profile
    {
        public MappingProfile()
        {
            CreateMap<UserProfile, UserDetails>().ReverseMap();
            CreateMap<TechnicalSkills, TechSkills>().ReverseMap();
            CreateMap<NonTechnicalSkills, NonTechSkills>().ReverseMap();
            CreateMap<UserDetails, CreateUserCommand>().ReverseMap();
            CreateMap<CreateUserCommand,UserProfile>().ReverseMap();
            CreateMap<UserUpdateProfile, UpdateUserProfileCommand>().ReverseMap();
        }
    }
}
