﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skill_TrackerCommonObjects
{
    public class RabbitMqConsts
    {
        public const string RabbitMqRootUri = "rabbitmq://localhost";
        public const string RabbitMqUri = "rabbitmq://localhost/userqueue";
        public const string UserName = "guest";
        public const string Password = "guest";
    }
}
