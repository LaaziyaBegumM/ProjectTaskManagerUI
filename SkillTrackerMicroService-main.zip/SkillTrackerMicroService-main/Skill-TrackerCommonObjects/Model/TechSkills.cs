﻿
namespace Skill_TrackerCommonObjects
{
    public class TechSkills
    {
        public string TechSkillName { get; set; }
        public int ExpertLevel { get; set; }
    }
}
