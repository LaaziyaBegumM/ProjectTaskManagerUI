﻿
namespace Skill_TrackerCommonObjects
{
    public class NonTechSkills
    {
        public string NonTechSkillName { get; set; }
        public int ExpertLevel { get; set; }
    }
}
