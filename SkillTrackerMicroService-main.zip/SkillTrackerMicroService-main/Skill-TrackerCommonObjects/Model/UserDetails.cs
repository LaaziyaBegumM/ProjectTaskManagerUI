﻿using System.Collections.Generic;

namespace Skill_TrackerCommonObjects
{
    public class UserDetails
    {
        public string AssociateId { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }       
        public List<TechSkills> TechnicalSkills { get; set; }
        public List<NonTechSkills> NonTechnicalSkills { get; set; }
    }
}
