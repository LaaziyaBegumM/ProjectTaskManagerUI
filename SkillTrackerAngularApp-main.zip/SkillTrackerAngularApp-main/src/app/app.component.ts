import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Nontechskills } from './nontechskills';
import { SearchprofileService } from './service/searchprofile.service';
import { Technicalskills } from './technicalskills';
import { UserProfile } from './userProfile';
import {HttpClient} from '@angular/common/http';
import { FormControl } from '@angular/forms';
import { SkillName } from './skill-name';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  name: string = '';
  associateId:string="";
  skill:string="";
  criteria!: string;
  criteriaValue!: string;
  userProfile!: any[]; 
  skillListObject:any[]= [{Item:'Angular'}, 
  {Item:'HTML-CSS-JAVASCRIPT'},
  {Item: 'React'},
  {Item:'Asp.net Core'},
  {Item:'Restful'},
  {Item:'Entity Framework'},
  {Item:'Git'},
  {Item:'Dcker'},
  {Item:'Jenkins'},
  {Item:'Azure'},
  {Item:'Spoken'},
  {Item:'Communication'},
  {Item:'Aptitude'}]; 
  
  constructor(private serviceProvider:SearchprofileService,private route: ActivatedRoute,private http : HttpClient) 
  {
    this.getSkillsInfo();  
  }
  ngOnInit():void{      
      
    this.criteria = this.route.snapshot.params['criteria'];     
    this.criteriaValue=this.route.snapshot.params["criteriaValue"] 
    this.getSkillsInfo();  
  } 
  GetUserProfile(criteriaName:string) {
    if(criteriaName.toLowerCase()=='name')
      this.criteriaValue=this.name;
    else if(criteriaName.toLowerCase()=="associateid")
      this.criteriaValue=this.associateId;
    else if(criteriaName.toLowerCase()=="skill")
      this.criteriaValue=this.skill;
    this.serviceProvider.getSearchProfile(criteriaName,this.criteriaValue).subscribe((data : any) => {      
    if (data != null && data.body != null) {
        var resultData = data.body.userProfile;
        if (resultData!=null) {         
          console.log(data.body)
          this.userProfile = resultData;   
        }
    }
      },
        async error => {
          (error: any) => {error.message };
        });
    }  
    getSkillsInfo(){
      return this.skillListObject;
    }   
}
