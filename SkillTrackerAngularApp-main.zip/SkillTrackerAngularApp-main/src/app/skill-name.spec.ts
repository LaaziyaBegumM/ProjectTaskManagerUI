import { SkillName } from './skill-name';

describe('SkillName', () => {
  it('should create an instance', () => {
    expect(new SkillName()).toBeTruthy();
  });
});
