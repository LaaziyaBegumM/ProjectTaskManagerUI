import { UserProfile } from './userProfile';

describe('Userdetails', () => {
  it('should create an instance', () => {
    expect(new UserProfile()).toBeTruthy();
  });
});
