import { Nontechskills } from './nontechskills';

describe('Nontechskills', () => {
  it('should create an instance', () => {
    expect(new Nontechskills()).toBeTruthy();
  });
});
