export class SkillName {
    Item:string="";  
}
