export class Technicalskills {
    TechSkillName:string="";
    ExpertLevel:number=0;
}
