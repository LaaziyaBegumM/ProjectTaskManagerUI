import { Technicalskills } from './technicalskills';

describe('Technicalskills', () => {
  it('should create an instance', () => {
    expect(new Technicalskills()).toBeTruthy();
  });
});
