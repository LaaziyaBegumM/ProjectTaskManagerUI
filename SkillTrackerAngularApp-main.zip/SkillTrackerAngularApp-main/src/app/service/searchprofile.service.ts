import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebapiService } from './webapi.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
var apiUrl = environment.apiUrl;

var httpLink = {
  getSearchProfile: apiUrl + "/api/admin/v1/search-profile" 
}
@Injectable({
  providedIn: 'root'
})
export class SearchprofileService {   
  constructor(private webApiService: WebapiService) { }
  
  public getSearchProfile(criteria: string,criteriaValue:string): Observable<any> {
    return this.webApiService.get(httpLink.getSearchProfile +'/'+ criteria+'/'+criteriaValue);
  }

}
