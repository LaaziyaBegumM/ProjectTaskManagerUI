import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { SearchprofileService } from './searchprofile.service';

describe('SearchprofileService', () => {
  let service: SearchprofileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchprofileService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should check getuserprofile success',()=>{      
    const resp={message:'success',statuscode:200,success:true,userProfile:[{}]};
    spyOn(service,"getSearchProfile").and.returnValue(of(resp));
    let criteriaName="Name";
    let criteriaValue="jo";
    service.getSearchProfile(criteriaName,criteriaValue);
    expect(service.getSearchProfile).toHaveBeenCalled();
  });
  it('should check getuserprofile no data',()=>{       
    const resp={message:'success',statuscode:200,success:true,userProfile:[]};
    spyOn(service,"getSearchProfile").and.returnValue(of(resp));
    let criteriaName="Name";
    let criteriaValue="89";
    service.getSearchProfile(criteriaName,criteriaValue);
    expect(service.getSearchProfile).toHaveBeenCalled();
  });
});
