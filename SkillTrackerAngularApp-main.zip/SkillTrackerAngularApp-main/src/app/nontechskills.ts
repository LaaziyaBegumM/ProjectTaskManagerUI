export class Nontechskills {
    NonTechSkillName:string="";
    ExpertLevel:number=0;
}
