import { Nontechskills } from "./nontechskills";
import { Technicalskills } from "./technicalskills";

export class UserProfile {
    AssociateId: string="";
    Name: string="";
    Mobile:string="";
    Email :string="";
    TechnicalSkill: Technicalskills[] = [];
    NonTechnicalSkill:Nontechskills[]=[];
}
