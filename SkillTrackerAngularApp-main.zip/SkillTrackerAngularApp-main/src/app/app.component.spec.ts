import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { AppComponent } from './app.component';
import { SearchprofileService } from './service/searchprofile.service';

describe('AppComponent', () => {
  let component: AppComponent;
  let searchprofileService: SearchprofileService ;
  let fixture:ComponentFixture<AppComponent>;  
  let router=Router;
  let http=HttpClient;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,FormsModule,HttpClientModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });
  beforeEach(() => {
      fixture = TestBed.createComponent(AppComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      }); 
  it('should check getuserprofile success',()=>{   
    let service = fixture.debugElement.injector.get(searchprofileService);
    const resp={message:'success',statuscode:200,success:true,userProfile:[{}]};
    spyOn(service,"getSearchProfile").and.returnValue(of(resp));
    let criteriaName="Name";
    component.name="jo";
    component.GetUserProfile(criteriaName);
    expect(service.getSearchProfile).toHaveBeenCalled();
  });
  it('should check getuserprofile no data',()=>{   
    let service = fixture.debugElement.injector.get(searchprofileService);
    const resp={message:'success',statuscode:200,success:true,userProfile:[]};
    spyOn(service,"getSearchProfile").and.returnValue(of(resp));
    let criteriaName="Name";
    component.name="89";
    component.GetUserProfile(criteriaName);
    expect(service.getSearchProfile).toHaveBeenCalled();
  });
});
